<!DOCTYPE html>
<!-- 
 Project name and version: CST-126 Activity Guide.Activity_6
 Programmer Name: Daniel Cutrara
 Date: 6/09/2019
 Synopsis: Use SQL Wildcard Searches to search for a pattern.
-->

<html>
<head>
<meta charset="ISO-8859-1">
<title>My Activity 6 Application</title>
</head>

<h2><?php echo $message?></h2>

<a href="login.html">Try Again</a>

</body>
</html>
