<?php
/*
 Project name and version: CST-126 Activity Guide.Activity_6
 Programmer Name: Daniel Cutrara
 Date: 6/09/2019
 Synopsis: Use SQL Wildcard Searches to search for a pattern.
*/
require_once 'myfuncs.php';
?>

<!DOCTYPE html>
<html lang="en">
<head> 
	<meta charset="UTF-8"> 
	<title>Who Am I</title>
</head>
<body> 

<h2>Hello My User ID Is: <?php echo " " . getUserId(); ?></h2>

<a href="index.html">home</a>

</body>
</html>